using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnAddArrows
{
    public int arrowsToGive;

    public OnAddArrows(int cnt)
    {
        arrowsToGive = cnt;
    }
}
