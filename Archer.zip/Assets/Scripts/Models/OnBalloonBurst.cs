using UnityEngine;

public class OnBalloonBurst 
{
    public int pointsToGive;
    public Vector3 position;
}
