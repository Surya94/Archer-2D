using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnUpdateStreak 
{
    public bool isStreakMaintained;
}
